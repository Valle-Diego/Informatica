package es181225;

public interface Abilita {
    String getNome();
    void usa(Combattente caster, Combattente target);
}
