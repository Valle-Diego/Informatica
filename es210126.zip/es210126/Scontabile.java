package es210126;

public interface Scontabile {
    double prezzoScontato(double percentuale);
}
