package es291025;

public class Piscina extends Impianto {

    public Piscina(String n, double Htar) {
        super(n, Htar);
    }
}

