Nome e Cognome: Valle [inserisci il tuo cognome completo]
Classe: [es. 4^A INF]

Descrizione:
Applicazione Java per la gestione di una Libreria Digitale.
Consente di:
- Aggiungere libri o eBook
- Visualizzare, cercare e rimuovere libri
- Ordinare il catalogo per titolo o autore
- Salvare e caricare i dati da file di testo

Estensioni realizzate:
✔ Classe EBook (ereditarietà)
✔ Ordinamento per titolo e autore
