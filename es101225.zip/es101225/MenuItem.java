package es101225;

public enum MenuItem {
    MARGHERITA(5.50),
    PROSCIUTTO(6.50),
    DIAVOLA(7.00),
    VEGETARIANA(6.80),
    BIRRA(3.00),
    BEVANDA(1.50);

    private final double prezzo;

    MenuItem(double prezzo) {
        this.prezzo = prezzo;
    }

    public double getPrezzo() {
        return prezzo;
    }
}
