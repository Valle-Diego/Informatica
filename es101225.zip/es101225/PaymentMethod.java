package es101225;

// Enum per i metodi di pagamento disponibili
public enum PaymentMethod {
    CASH, CARD, APP
}
