package es101225;

public enum PaymentMethod {
    CASH, CARD, APP
}
