package es101225;

public class OrderManager {
    private Ordine[] ordini = new Ordine[100];
    private int count = 0;

    public void addOrdine(Ordine o) {
        ordini[count++] = o;
    }

    public double totaleIncasso() {
        double totale = 0;
        for (int i = 0; i < count; i++) {
            totale += ordini[i].calcolaTotale();
        }
        return totale;
    }

    public int numeroOrdini() {
        return count;
    }

    public void stampaRiepilogo() {
        for (int i = 0; i < count; i++) {
            System.out.println(ordini[i]);
        }
        System.out.println("INCASSO TOTALE: " + totaleIncasso());
        System.out.println("ORDINI: " + numeroOrdini());
    }
}
