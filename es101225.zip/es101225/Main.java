package es101225;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        OrderManager manager = new OrderManager();

        // Ordine asporto
        Ordine o1 = new OrdineAsporto(PaymentMethod.CARD);
        o1.aggiungiItem(MenuItem.MARGHERITA, 2);
        o1.aggiungiItem(MenuItem.BIRRA, 1);
        manager.addOrdine(o1);

        // Ordine domicilio
        Ordine o2 = new OrdineDomicilio(PaymentMethod.CASH, "Via Roma 10");
        o2.aggiungiItem(MenuItem.DIAVOLA, 1);
        o2.aggiungiItem(MenuItem.BEVANDA, 2);
        manager.addOrdine(o2);

        // Stampa riepilogo
        manager.stampaRiepilogo();

        // Inserimento console semplice
        Scanner sc = new Scanner(System.in);
        System.out.println("Vuoi inserire un nuovo ordine? (s/n)");
        String risp = sc.nextLine();
        if (risp.equalsIgnoreCase("s")) {
            System.out.println("Tipo consegna (1=asporto, 2=domicilio):");
            int tipo = Integer.parseInt(sc.nextLine());
            Ordine nuovo;
            if (tipo == 1) {
                nuovo = new OrdineAsporto(PaymentMethod.CASH);
            } else {
                System.out.println("Inserisci indirizzo:");
                String ind = sc.nextLine();
                nuovo = new OrdineDomicilio(PaymentMethod.CARD, ind);
            }
            while (true) {
                System.out.println("Scrivi nome ITEM o 'fine':");
                String it = sc.nextLine();
                if (it.equalsIgnoreCase("fine")) break;
                try {
                    MenuItem mi = MenuItem.valueOf(it.toUpperCase());
                    System.out.println("Quantità:");
                    int q = Integer.parseInt(sc.nextLine());
                    nuovo.aggiungiItem(mi, q);
                } catch (Exception e) {
                    System.out.println("Elemento non valido, riprova");
                }
            }
            manager.addOrdine(nuovo);
            manager.stampaRiepilogo();
        }
        sc.close();
    }
}
