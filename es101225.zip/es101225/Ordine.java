package es101225;

public abstract class Ordine {
    private static int counter = 1;
    protected int id;
    protected PaymentMethod paymentMethod;

    protected MenuItem[] items = new MenuItem[100];
    protected int[] quantita = new int[100];
    protected int count = 0;

    public Ordine(PaymentMethod pm) {
        this.id = counter++;
        this.paymentMethod = pm;
    }

    public void aggiungiItem(MenuItem item, int q) {
        if (q <= 0) return;
        for (int i = 0; i < count; i++) {
            if (items[i] == item) {
                quantita[i] += q;
                return;
            }
        }
        items[count] = item;
        quantita[count] = q;
        count++;
    }

    public double getTotaleBase() {
        double totale = 0;
        for (int i = 0; i < count; i++) {
            totale += items[i].getPrezzo() * quantita[i];
        }
        return totale;
    }

    public abstract double calcolaTotale();

    public String toString() {
        String s = "Ordine #" + id + "\n";
        for (int i = 0; i < count; i++) {
            s += items[i].name() + " x" + quantita[i] + " @ " + items[i].getPrezzo() + "\n";
        }
        s += "Totale base: " + getTotaleBase() + "\n";
        s += "Metodo pagamento: " + paymentMethod + "\n";
        return s;
    }
}
